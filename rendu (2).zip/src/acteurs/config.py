
# Constantes
NB_SERVEURS: int = 10                   # Nombre de serveurs
PUISSANCE_RANGE: tuple = (10, 100, 25)  # Prise d'une puissance au hasard 

